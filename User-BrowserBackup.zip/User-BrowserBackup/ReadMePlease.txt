Thanks for downloading Del92's User-BrowserBackup / UserEverythingBackup < Not sure yet on the name..

*******************************************DISCLAIMER****************************************************************************************************  
This software is provided "as is" without warranty of any kind. I am not responsible for any damage that may (or) may not occur 
You may use this software at your own risk. 
This software is free to use DO NOT CHANGE OR STEAL THIS SOFTWARE "to claim as your own". Otherwise have fun. Please Credit creator when possible. 
*******************************************DISCLAIMER**************************************************************************************************** 
This program should be extracted on a External Backup drive or usb drive to then be carried to new computer to restore data.

This program will Create several folders all under "BACKUPBROWSER-USER" of root drive you run it on. Hence why running it on the SystemDrive is not recommended.

This program does require Local Administrative access, Please add user to be backed up under Computer management Administrator group. 
then Restart computer and run software again.

This program uses 7zip to zip UserData, Firefox profile data, Chrome Profile Data, etc... Then restore that same data to new user profile or new computer profile data.

This program can create a new user giving the choice of Administrative access when created.

Inside of BACKUPBROWSER-USER\ "CHROMEBACKUP", "FIREFOXBACKUP", "USERBACKUP"

Inside of CHROMEBACKUP\ Computername ie, "John-PC"\ "username"\ "CHROME.7Z"

Inside of FIREFOXBACKUP\ Computername ie, "John-PC"\ "Username"\ "FIREFOXappdata.7z", "FIREFOXroam.7z"

Inside of USERBACKUP\ Computername ie, "John-PC"\ "Username"\ "Username.7z"

This program has potential to be great its a side project I have been working on and off for about 2 years it came out of necessity as I do alot of IT work
that required backing up User profile data and restoring to new computers and I just could not find a good software that did it all in one and was simple to use.

I use it almost daily changing and adding to it almost monthly. Adding new things, Changing how the software is written. "It's not perfect yet" 

Chrome backup/restore does not currently work because when profile data is restored chrome auto resets to default profile settings. Working on a fix for this issue.


